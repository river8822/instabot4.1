# Ultimate script with schedule

This script uses [schedule](https://github.com/dbader/schedule) to do tasks. Just look at the code and change it - it should be clear enough.

To install _schedule_ module:
```
pip install schedule
```
