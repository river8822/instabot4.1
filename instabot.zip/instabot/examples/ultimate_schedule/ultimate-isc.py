# -*- coding: utf-8 -*-
# Instabot Version 4.0.1 Mod By Isaac Ch

from glob import glob
import os
import sys
import threading
import time

sys.path.append(os.path.join(sys.path[0], '../../'))
import schedule
from instabot import Bot, utils

import config

bot = Bot(filter_users=False,
          max_follows_per_day=300,
          max_unfollows_per_day=400,
          max_comments_per_day=40,
          like_delay=30,
          follow_delay=40,
          unfollow_delay=40,
          comment_delay=120,
          comments_file=config.COMMENTS_FILE,
          blacklist_file=config.BLACKLIST_FILE,
          whitelist_file=config.WHITELIST_FILE,
          friends_file=config.FRIENDS_FILE)
bot.login(username="usuario", password="password")
bot.logger.info("ULTIMATE script. Safe 24/7! Mod by Isaac Ch.")

random_post_hashtags = utils.file(config.POST_HASHTAGS)
random_user_file = utils.file(config.USERS_FILE)
random_hashtag_file = utils.file(config.HASHTAGS_FILE)
photo_captions_file = utils.file(config.PHOTO_CAPTIONS_FILE)
posted_pic_list = utils.file(config.POSTED_PICS_FILE).list

pics = sorted([os.path.basename(x) for x in
               glob(config.PICS_PATH + "/*.jpg")])

posts = sorted([os.path.basename(x) for x in
               glob(config.POSTS_PATH + "/*.jpg")])

def stats():
    bot.save_user_stats(bot.user_id)


def like_hashtags():
    bot.like_hashtag(random_hashtag_file.random(), amount=700 // 24)


def like_timeline():
    bot.like_timeline(amount=300 // 24)


def like_followers_from_random_user_file():
    bot.like_followers(random_user_file.random(), nlikes=3)


def follow_followers():
    bot.follow_followers(random_user_file.random())


def comment_medias():
    bot.comment_medias(bot.get_timeline_medias())


def unfollow_non_followers():
    bot.unfollow_non_followers()


def follow_users_from_hastag_file():
    bot.follow_users(bot.get_hashtag_users(random_hashtag_file.random()))


def comment_hashtag():
    hashtag = random_hashtag_file.random()
    bot.logger.info("Commenting on hashtag: " + hashtag)
    bot.comment_hashtag(hashtag)


def upload_pictures():  # Automatically post a pic in 'pics' folder
    try:
        for pic in pics:
            if pic in posted_pic_list:
                continue

            caption = photo_captions_file.random()
            full_caption = caption + "\n" + config.FOLLOW_MESSAGE
            bot.logger.info("Uploading pic with caption: " + caption)
            bot.upload_photo(config.PICS_PATH + pic, caption=full_caption)
            if bot.api.last_response.status_code != 200:
                bot.logger.error("Something went wrong, read the following ->\n")
                bot.logger.error(bot.api.last_response)
                break

            if pic not in posted_pic_list:
                # After posting a pic, comment it with all the hashtags specified
                # In config.POST_HASHTAGS Mod by Isaac Ch.
                posted_pic_list.append(pic)
                with open('pics.txt', 'a') as f:
                    f.write(pic + "\n")
                bot.logger.info("Succesfully uploaded: " + pic)
                bot.logger.info("Commenting uploaded photo with hashtags...")
                medias = bot.get_your_medias()
                last_photo = medias[0]  # Get the last photo posted
                bot.comment(last_photo, random_post_hashtags.random())
                bot.logger.info("Post and Comment Successfully!!...")

                break
    except Exception as e:
        bot.logger.error("Couldn't upload pic")
        bot.logger.error(str(e))


def put_non_followers_on_blacklist():  # put non followers on blacklist
    try:
        bot.logger.info("Creating non-followers list")
        followings = set(bot.following)
        followers = set(bot.followers)
        friends = bot.friends_file.set  # same whitelist (just user ids)
        non_followers = followings - followers - friends
        for user_id in non_followers:
            bot.blacklist_file.append(user_id, allow_duplicates=False)
        bot.logger.info("Done.")
    except Exception as e:
        bot.logger.error("Couldn't update blacklist")
        bot.logger.error(str(e))


def run_threaded(job_fn):
    job_thread = threading.Thread(target=job_fn)
    job_thread.start()


def unfollow_everyone(): # Dejar de seguir a todos sin filtrar, Mod by Isaac Ch.
    bot.unfollow_everyone()

def upload_posts():  # Post+Caption programado en orden segun el nombre del archivo,
                     # ej: "1 que linda imagen.jpg", "2 otra linda imagen.jpg", mod by Isaac Ch.
    try:
        for pic in posts:
            if pic in posted_pic_list:
                continue

            caption = pic[:-4].split(" ")
            caption = " ".join(caption[1:])
            bot.logger.info("Uploading pic with caption: " + caption)
            bot.upload_photo(config.POSTS_PATH + pic, caption=caption)
            if bot.api.last_response.status_code != 200:
                bot.logger.error("Something went wrong, read the following ->\n")
                bot.logger.error(bot.api.last_response)
                break

            if pic not in posted_pic_list:
                # After posting a pic, comment it with all the hashtags specified
                # In config.POST_HASHTAGS
                posted_pic_list.append(pic)
                with open('pics.txt', 'a') as f:
                    f.write(pic + "\n")
                bot.logger.info("Succesfully uploaded: " + pic)
                bot.logger.info("Commenting uploaded photo with hashtags...")
                medias = bot.get_your_medias()
                last_photo = medias[0]  # Get the last photo posted
                bot.comment(last_photo, random_post_hashtags.random())
                bot.logger.info("SUPEERRR Post and Comment Successfully!!...")
                break
    except Exception as e:
        bot.logger.error("Couldn't upload pic")
        bot.logger.error(str(e))
		

# Programacion lista para colocar la task a las 14:55 UTC.

schedule.every(1).days.at("15:00").do(run_threaded, stats)
schedule.every(10).days.at("15:01").do(run_threaded, put_non_followers_on_blacklist)

# schedule.every(1).days.at("15:02").do(run_threaded, upload_pictures)
# schedule.every(1).days.at("15:08").do(run_threaded, upload_posts)
# schedule.every(1).days.at("15:15").do(run_threaded, upload_pictures)

schedule.every(1).monday.at("15:10").do(run_threaded, follow_followers)
schedule.every(1).tuesday.at("15:10").do(run_threaded, unfollow_everyone)
schedule.every(1).wednesday.at("15:10").do(run_threaded, unfollow_everyone)
schedule.every(1).thursday.at("15:10").do(run_threaded, unfollow_non_followers)
schedule.every(1).friday.at("15:10").do(run_threaded, follow_followers)
schedule.every(1).saturday.at("15:10").do(run_threaded, follow_followers)
schedule.every(1).sunday.at("15:10").do(run_threaded, follow_followers)

schedule.every(1).monday.at("16:30").do(run_threaded, comment_hashtag)
schedule.every(1).tuesday.at("16:30").do(run_threaded, like_hashtags)
schedule.every(1).wednesday.at("16:30").do(run_threaded, comment_medias)
schedule.every(1).thursday.at("16:30").do(run_threaded, like_timeline)
schedule.every(1).friday.at("16:30").do(run_threaded, comment_hashtag)
schedule.every(1).saturday.at("16:30").do(run_threaded, like_hashtags)
schedule.every(1).sunday.at("16:30").do(run_threaded, comment_medias)

# schedule.every(1).days.at("16:00").do(run_threaded, like_followers_from_random_user_file)
# schedule.every(12).hours.do(run_threaded, follow_users_from_hastag_file)


while True:
    schedule.run_pending()
    time.sleep(1)
